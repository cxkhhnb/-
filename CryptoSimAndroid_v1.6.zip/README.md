# Crypto Sim Pro+ Android project

This project wraps the Crypto Sim Pro+ virtual trading app in an Android WebView.

## Markets
- Crypto: Binance public REST candles and order-book snapshot for selected USDT pairs.
- US stocks: Yahoo Finance Chart endpoint (unofficial public endpoint; may be delayed, rate limited, or blocked in some networks). Symbols include major equities/ETFs (AAPL, MSFT, NVDA, TSLA, AMZN, GOOGL, META, AMD, NFLX, SPY, QQQ, COIN, PLTR, INTC, DIS, BABA) and indices (^GSPC S&P 500, ^IXIC Nasdaq Composite, ^DJI Dow Jones, ^RUT Russell 2000, ^VIX volatility index).
- Simulated long/short trades, leverage, take-profit/stop-loss, fees and liquidation approximation are virtual only.

## Build APK using GitHub Actions
1. Upload this folder's contents to a GitHub repository (root should contain `settings.gradle` and `app/`).
2. Open Actions tab, run `Build Android APK` (or push to `main`).
3. Download artifact `CryptoSimPro-debug-apk` from the completed workflow.
4. Install the APK on Android.

Requires Android 6+ (min SDK 23). No trading account or API key is used.

Market data and chart CDN require internet access. US stock chart API is unofficial and availability may vary. Simulator is not investment advice and does not execute real trades.

## Pro upgrade (2026-11)
- EMA 20 / EMA 50 overlays and RSI 14 readout (approximate indicator calculation).
- Quick watchlist shortcuts for crypto and stocks/index symbols.
- Browser local-storage persistence for account state and trade history. Clearing app/browser storage resets it.
- Configurable one-shot price alert (trigger checked on price refresh).
- Added S&P 500, Nasdaq Composite, Dow Jones, Russell 2000, and VIX index symbols.


## vNext+2 Upgrade
- Added trade performance panel: closed trade count, win rate, average winner/loser, profit-loss ratio, best/worst trade.
- Added local practice missions, a clearly-labelled simulated leaderboard, CSV trade export and trade notes.
- Notes stored locally in browser storage; CSV export is client-side. Reset button resets the simulator state.
- These features are educational simulations, not financial advice or real trading.

## v1.4 Upgrade
- Realized PnL curve and monthly PnL summaries
- Monthly trade count and profitable day count
- Custom EMA crossover backtest parameters and fee estimates


## v1.6 更新
- 规则化市场分析面板：EMA20/50、RSI14 与指标评分（不是 AI）。
- 同样历史行情下比较 EMA 8/21、12/26、20/50、20/100、50/100 策略。
- 训练积分与纪律分（本地模拟）。
- 本地账户 JSON 备份与恢复。
- Android versionName 1.6 / versionCode 6。
